﻿internal class Program
{
    private static void Main(string[] args)
    {
        Console.WriteLine("Problema 1");
        int meses = 20;
        double pagoMensual = 10;
        double totalPagado = 0;

        Console.WriteLine("Mes \t Pago mensual");
        for (int i = 1; i <= meses; i++)
        {
            Console.WriteLine(i + "\t" + pagoMensual);
            totalPagado += pagoMensual;
            pagoMensual *= 2;
        }
        Console.WriteLine("Total pagado: " + totalPagado);
    }
}