﻿internal class Program
{
    private static void Main(string[] args)
    {
        Console.WriteLine("Problema 2");
        Console.Write("Ingrese el número de empleados: ");
        int numEmpleados = Convert.ToInt32(Console.ReadLine());

        double sueldoTotal = 0;

        
        for (int i = 1; i <= numEmpleados; i++)
        {
            Console.WriteLine("Empleado #" + i);
            Console.Write("Ingrese el número de días trabajados: ");
            int numDias = Convert.ToInt32(Console.ReadLine());

            Console.Write("Ingrese el pago por hora del empleado: Q ");
            double pagoHora = Convert.ToDouble(Console.ReadLine());

            double sueldoEmpleado = 0;

            
            for (int j = 1; j <= numDias; j++)
            {
                Console.Write("Ingrese las horas trabajadas en el día " + j + ": ");
                double horasTrabajadas = Convert.ToDouble(Console.ReadLine());
                sueldoEmpleado += horasTrabajadas * pagoHora;
            }

            Console.WriteLine("El sueldo semanal del empleado #" + i + " es de Q " + sueldoEmpleado);
            sueldoTotal += sueldoEmpleado;
        }

        Console.WriteLine("La empresa pagó un total de Q " + sueldoTotal + " por los " + numEmpleados + " empleados.");
    }
}