﻿internal class Program
{
    private static void Main(string[] args)
    {
        Console.WriteLine("Problema 3");
        int q0_01, q0_05, q0_10, q0_25, q0_50, q1, q5, q10, q20, q50, q100, q200;
        Console.WriteLine("Ingrese el número de billetes y monedas de cada denominación:");
        Console.Write("1 centavo: ");
        q0_01 = int.Parse(Console.ReadLine());
        Console.Write("5 centavos: ");
        q0_05 = int.Parse(Console.ReadLine());
        Console.Write("10 centavos: ");
        q0_10 = int.Parse(Console.ReadLine());
        Console.Write("25 centavos: ");
        q0_25 = int.Parse(Console.ReadLine());
        Console.Write("50 centavos: ");
        q0_50 = int.Parse(Console.ReadLine());
        Console.Write("1 quetzal: ");
        q1 = int.Parse(Console.ReadLine());
        Console.Write("5 quetzales: ");
        q5 = int.Parse(Console.ReadLine());
        Console.Write("10 quetzales: ");
        q10 = int.Parse(Console.ReadLine());
        Console.Write("20 quetzales: ");
        q20 = int.Parse(Console.ReadLine());
        Console.Write("50 quetzales: ");
        q50 = int.Parse(Console.ReadLine());
        Console.Write("100 quetzales: ");
        q100 = int.Parse(Console.ReadLine());
        Console.Write("200 quetzales: ");
        q200 = int.Parse(Console.ReadLine());

        
        decimal total = q0_01 * 0.01m + q0_05 * 0.05m + q0_10 * 0.10m + q0_25 * 0.25m +
                        q0_50 * 0.50m + q1 + q5 * 5 + q10 * 10 + q20 * 20 +
                        q50 * 50 + q100 * 100 + q200 * 200;

        
        Console.WriteLine("El total en caja es: {0} quetzales", total);
    }
}