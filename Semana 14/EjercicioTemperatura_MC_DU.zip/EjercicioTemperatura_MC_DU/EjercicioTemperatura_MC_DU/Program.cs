﻿internal class Program
{
    private static void Main(string[] args)
    {
        const int NUM_DIAS = 7;
        const int NUM_HORAS = 2;
        const int TEMP_MIN = 15;
        const int TEMP_MAX = 35;

        int[,] temperaturas = new int[NUM_DIAS, NUM_HORAS];
        Random rand = new Random();

        // Llenar la matriz con valores aleatorios entre TEMP_MIN y TEMP_MAX
        for (int i = 0; i < NUM_DIAS; i++)
        {
            for (int j = 0; j < NUM_HORAS; j++)
            {
                temperaturas[i, j] = rand.Next(TEMP_MIN, TEMP_MAX + 1);
            }
        }

        // Mostrar las temperaturas
        Console.WriteLine("Diego Urbina_1219823 Mauricio Cabrera_1073323");
        Console.WriteLine("Las filas representan los días, y cada fila contiene las temperaturas de la mañana y la tarde para ese día en particular" +
        "Las columnas representan las dos mediciones de temperatura para cada día.");
        Console.WriteLine("Se escogió el tipo de dato int para almacenar las temperaturas porque se decidió que las temperaturas serían números " +
            "enteros, y no había necesidad de utilizar un tipo de dato como double. " +
            "Además, se decidió que los valores aleatorios " +
            "generados para las temperaturas estarían en el rango de 15 a 35 grados Celsius,");
        Console.WriteLine("Temperaturas de la última semana:");
        Console.WriteLine("Día\tMañana\tTarde");
        for (int i = 0; i < NUM_DIAS; i++)
        {
            Console.WriteLine("{0}\t{1}\t{2}", i + 1, temperaturas[i, 0], temperaturas[i, 1]);
        }

        // Calcular el promedio de las temperaturas de los últimos 3 días en la mañana
        double promedioUltimos3DiasMañana = 0;
        for (int i = NUM_DIAS - 1; i >= NUM_DIAS - 3; i--)
        {
            promedioUltimos3DiasMañana += temperaturas[i, 0];
        }
        promedioUltimos3DiasMañana /= 3;
        Console.WriteLine("Promedio de la temperatura de los últimos 3 días en la mañana: {0}", promedioUltimos3DiasMañana);

        // Encontrar el día más caluroso por la tarde
        int diaMasCalurosoTarde = 0;
        int tempDiaMasCalurosoTarde = temperaturas[0, 1];
        for (int i = 1; i < NUM_DIAS; i++)
        {
            if (temperaturas[i, 1] > tempDiaMasCalurosoTarde)
            {
                diaMasCalurosoTarde = i;
                tempDiaMasCalurosoTarde = temperaturas[i, 1];
            }
        }
        Console.WriteLine("Día más caluroso por la tarde: {0}", GetNombreDiaSemana(diaMasCalurosoTarde));

        // Encontrar el día menos caluroso por la mañana
        int diaMenosCalurosoMañana = 0;
        int tempDiaMenosCalurosoMañana = temperaturas[0, 0];
        for (int i = 1; i < NUM_DIAS; i++)
        {
            if (temperaturas[i, 0] < tempDiaMenosCalurosoMañana)
            {
                diaMenosCalurosoMañana = i;
                tempDiaMenosCalurosoMañana = temperaturas[i, 0];
            }
        }
        Console.WriteLine("Día menos caluroso por la mañana: {0}", GetNombreDiaSemana(diaMenosCalurosoMañana));

        // Contar cuántos días tienen temperatura menor a 30 grados por la mañana y por la tarde
        int numDiasMenos30Mañana = 0;
        int numDiasMenos30Tarde = 0;
        for (int i = 0; i < NUM_DIAS; i++)
        {
            if (temperaturas[i, 0] < 30)
            {
                numDiasMenos30Mañana++;
            }
            if (temperaturas[i, 1] < 30)
            {
                numDiasMenos30Tarde++;
            }
        }
        Console.WriteLine("Días con temperatura menor a 30 grados por la mañana: {0}", numDiasMenos30Mañana);
        Console.WriteLine("Días con temperatura menor a 30 grados por la tarde: {0}", numDiasMenos30Tarde);
        // Determinar si es una temporada calurosa
        double promedioTarde = 0;
        for (int i = 0; i < NUM_DIAS; i++)
        {
            promedioTarde += temperaturas[i, 1];
        }
        promedioTarde /= NUM_DIAS;
        if (promedioTarde > 30)
        {
            Console.WriteLine("Es una temporada calurosa");
        }
        else
        {
            Console.WriteLine("No es una temporada calurosa");
        }
    }

    static string GetNombreDiaSemana(int numDia)
    {
        switch (numDia)
        {
            case 0:
                return "Domingo";
            case 1:
                return "Lunes";
            case 2:
                return "Martes";
            case 3:
                return "Miércoles";
            case 4:
                return "Jueves";
            case 5:
                return "Viernes";
            case 6:
                return "Sábado";
            default:
                throw new ArgumentException("Número de día inválido");
        }
    }
}