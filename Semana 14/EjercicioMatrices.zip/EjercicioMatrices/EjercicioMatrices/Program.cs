﻿internal class Program
{
    private static void Main(string[] args)
    {
        // Definir constantes
        const int NUM_ASIGNATURAS = 6;
        const int NUM_ALUMNOS = 30;

        // matriz para almacenar notas
        float[,] notasAlumnos = new float[NUM_ALUMNOS, NUM_ASIGNATURAS];

        // Ingreso notas
        for (int i = 0; i < NUM_ALUMNOS; i++)
        {
            Console.WriteLine("Ingrese las notas del alumno {0}:", i + 1);

            for (int j = 0; j < NUM_ASIGNATURAS; j++)
            {
                Console.Write("Asignatura {0}: ", j + 1);
                notasAlumnos[i, j] = float.Parse(Console.ReadLine());
            }
        }

        // media de notas por alumno y por asignatura
        float[] mediasAlumnos = new float[NUM_ALUMNOS];
        float[] mediasAsignaturas = new float[NUM_ASIGNATURAS];

        for (int i = 0; i < NUM_ALUMNOS; i++)
        {
            for (int j = 0; j < NUM_ASIGNATURAS; j++)
            {
                mediasAlumnos[i] += notasAlumnos[i, j];
                mediasAsignaturas[j] += notasAlumnos[i, j];
            }

            mediasAlumnos[i] /= NUM_ASIGNATURAS;
        }

        for (int j = 0; j < NUM_ASIGNATURAS; j++)
        {
            mediasAsignaturas[j] /= NUM_ALUMNOS;
        }

        // Mostrar resultados
        Console.WriteLine("Media de notas por alumno:");

        for (int i = 0; i < NUM_ALUMNOS; i++)
        {
            Console.WriteLine("Alumno {0}: {1}", i + 1, mediasAlumnos[i]);
        }

        Console.WriteLine("Media de notas por asignatura:");

        for (int j = 0; j < NUM_ASIGNATURAS; j++)
        {
            Console.WriteLine("Asignatura {0}: {1}", j + 1, mediasAsignaturas[j]);
        }

        Console.ReadKey();
    }
}