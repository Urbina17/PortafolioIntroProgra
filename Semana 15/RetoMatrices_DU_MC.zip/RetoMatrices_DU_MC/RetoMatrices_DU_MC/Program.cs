﻿class Equipo
{
    public string nombre;
    public int partidosJugados;
    public int partidosGanados;
    public int partidosEmpatados;
    public int partidosPerdidos;
    public int golesAFavor;
    public int golesEnContra;
}
internal class Program
{
    private static void Main(string[] args)
    {
        Console.Write("Ingrese la cantidad de equipos que jugaron: ");
        int cantidadEquipos = int.Parse(Console.ReadLine());

        List<Equipo> equipos = new List<Equipo>();

        // Generar los equipos y su información aleatoria
        for (int i = 0; i < cantidadEquipos; i++)
        {
            Equipo equipo = new Equipo();
            Console.Write("Ingrese el nombre del equipo #" + (i + 1) + ": ");
            equipo.nombre = Console.ReadLine();

            while (equipos.Any(e => e.nombre == equipo.nombre))
            {
                Console.Write("El nombre del equipo ya existe, ingrese otro: ");
                equipo.nombre = Console.ReadLine();
            }

            equipo.partidosJugados = GenerarNumeroAleatorio(15, 15);
            equipo.partidosGanados = GenerarNumeroAleatorio(0, equipo.partidosJugados);
            equipo.partidosEmpatados = GenerarNumeroAleatorio(0, equipo.partidosJugados - equipo.partidosGanados);
            equipo.partidosPerdidos = equipo.partidosJugados - equipo.partidosGanados - equipo.partidosEmpatados;
            equipo.golesAFavor = GenerarNumeroAleatorio(0, 50);
            equipo.golesEnContra = GenerarNumeroAleatorio(0, 50);

            equipos.Add(equipo);
        }

        // Mostrar la tabla de posiciones
        Console.WriteLine("Tabla de posiciones:");
        Console.WriteLine("{0,-20} {1,-5} {2,-5} {3,-5} {4,-5} {5,-5} {6,-5} {7,-5}", "Equipo", "PJ", "PG", "PE", "PP", "GF", "GC", "Puntos");
        foreach (var equipo in equipos)
        {
            int puntos = equipo.partidosGanados * 3 + equipo.partidosEmpatados;
            Console.WriteLine("{0,-20} {1,-5} {2,-5} {3,-5} {4,-5} {5,-5} {6,-5} {7,-5}", equipo.nombre, equipo.partidosJugados, equipo.partidosGanados, equipo.partidosEmpatados, equipo.partidosPerdidos, equipo.golesAFavor, equipo.golesEnContra, puntos);
        }

        // Equipo con más goles a favor
        var equipoMasGolesAFavor = equipos.OrderByDescending(e => e.golesAFavor).First();
        Console.WriteLine("Equipo con más goles a favor: " + equipoMasGolesAFavor.nombre);

        // Equipo con menos goles en contra
        var equipoMenosGolesEnContra = equipos.OrderBy(e => e.golesEnContra).First();
        Console.WriteLine("Equipo con menos goles en contra: " + equipoMenosGolesEnContra.nombre);
        // Promedio de partidos jugados
        double promedioPartidosJugados = equipos.Average(e => e.partidosJugados);
        Console.WriteLine("Promedio de partidos jugados: " + promedioPartidosJugados);

        // Equipo con más partidos ganados
        var equipoMasPartidosGanados = equipos.OrderByDescending(e => e.partidosGanados).First();
        Console.WriteLine("Equipo con más partidos ganados: " + equipoMasPartidosGanados.nombre);

        // Total de goles a favor y en contra
        int totalGolesAFavor = equipos.Sum(e => e.golesAFavor);
        int totalGolesEnContra = equipos.Sum(e => e.golesEnContra);
        Console.WriteLine("Total de goles a favor: " + totalGolesAFavor);
        Console.WriteLine("Total de goles en contra: " + totalGolesEnContra);

        // Equipo con más partidos empatados
        var equipoMasPartidosEmpatados = equipos.OrderByDescending(e => e.partidosEmpatados).First();
        Console.WriteLine("Equipo con más partidos empatados: " + equipoMasPartidosEmpatados.nombre);

        // Equipos sobre el promedio de goles a favor
        var equiposSobrePromedioGolesAFavor = equipos.Where(e => e.golesAFavor > promedioPartidosJugados);
        Console.WriteLine("Equipos sobre el promedio de goles a favor:");
        foreach (var equipo in equiposSobrePromedioGolesAFavor)
        {
            Console.WriteLine("- " + equipo.nombre);
        }

        Console.ReadKey();
    }

    static int GenerarNumeroAleatorio(int minimo, int maximo)
    {
        Random random = new Random();
        return random.Next(minimo, maximo + 1);
    }

}
