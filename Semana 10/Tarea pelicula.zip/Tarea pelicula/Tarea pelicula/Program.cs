﻿using Tarea_pelicula;

internal class Program
{
    private static void Main(string[] args)
    {
        List<Pelicula> peliculas = new List<Pelicula>();

        peliculas.Add(new Pelicula("Ghandi","Richard Attenborough", 191, Genero.DRAMA, 2016) { Calificacion = 8.1 });
        peliculas.Add(new Pelicula("Thor","Kenneth Branagh", 115, Genero.ACCION, 2011) { Calificacion = 7.0 });


        Console.WriteLine("{0,-10} {1,-30} {2,-20} {3,-10} {4,-10} {5,-15} {6,-10}", "Objeto", "Nombre", "Director", "Género", "Duración", "Año", "Calificacion");

        for (int i = 0; i < peliculas.Count; i++)
        {
            Pelicula peliculaActual = peliculas[i];
            Console.WriteLine("{0,-10} {1,-30} {2,-20} {3,-10} {4,-10} {5,-15} {6,-10}", "Pelicula " + (i + 1), peliculaActual.Nombre, peliculaActual.Director, peliculaActual.Genero, peliculaActual.Duracion, peliculaActual.Año, peliculaActual.Calificacion);
        }
    }
}