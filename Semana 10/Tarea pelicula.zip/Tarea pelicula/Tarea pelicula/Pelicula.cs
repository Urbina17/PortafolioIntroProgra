﻿using System;
using System.Collections.Generic;
using System.Collections.Specialized;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Tarea_pelicula
{
    public class Pelicula
    {
        public string Nombre { get; set; }
        public string Director { get; set; }
        public int Duracion { get; set; }
        public Genero Genero { get; set; }
        public int Año { get; set; }
        public double Calificacion { get; set; }

        public Pelicula(string nombre,string director, int duracion, Genero genero, int año)
        {
            Nombre = nombre;
            Director = director;
            Duracion = duracion;
            Genero = genero;
            Año = año;
        }

        public void ImprimirInformacion()
        {
            Console.WriteLine("Nombre: {0}", Nombre);
            Console.WriteLine("Director: {0}", Director);
            Console.WriteLine("Duración: {0} minutos", Duracion);
            Console.WriteLine("Género: {0}", Genero);
            Console.WriteLine("Año: {0}", Año);
            Console.WriteLine("Calificación: {0}", Calificacion);
        }

        public bool EsPeliculaEpica()
        {
            return Duracion >= 180;
        }

        public string ObtenerValoracion()
        {
            if (Calificacion >= 8)
            {
                return "Excelente";
            }
            else if (Calificacion > 7)
            {
                return "Buena";
            }
            else if (Calificacion > 5)
            {
                return "Regular";
            }
            else if (Calificacion > 2)
            {
                return "Mala";
            }
            else
            {
                return "Muy mala";
            }
        }

        public bool EsSimilar(Pelicula otraPelicula)
        {
            return Genero == otraPelicula.Genero && Calificacion == otraPelicula.Calificacion;
        }
    }

    public enum Genero
    {
        ACCION,
        COMEDIA,
        DRAMA,
        SUSPENSO
    }
}
