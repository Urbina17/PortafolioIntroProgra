﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Desafio_personal
{
    internal class Libro
    {
        private int Id;
        private string Nombre;
        private int NumPaginas;
        private int PaginasLeidas;
        private bool leido;

        private const string CODIGO = "9788478889907";

        public Libro(int id, string nombre, int numPaginas)
        {
            Id = id;
            Nombre = nombre;
            NumPaginas = numPaginas;
            
            leido = false;
        }

        public void Leer(int paginasLeidas)

        {
            PaginasLeidas= paginasLeidas;
            if (paginasLeidas <= 0)
            {
                Console.WriteLine("Error: la cantidad de páginas a leer debe ser mayor a 0.");
            }
            else if (paginasLeidas > NumPaginas)
            {
                Console.WriteLine("Error: la cantidad de páginas a leer supera el número total de páginas del libro.");
            }
            else
            {
                
                if (paginasLeidas == NumPaginas)
                {
                    leido = true;
                }
            }
        }

        public double ObtenerPorcentajeLectura()
        {
            return (double)PaginasLeidas / NumPaginas * 100;
        }

        public int ObtenerPaginaActual()
        {
            return PaginasLeidas + 1;
        }

        public void MostrarLibro()
        {
            Console.WriteLine("Código: " + CODIGO);
            Console.WriteLine("Nombre: " + Nombre);
            Console.WriteLine("Número de páginas: " + NumPaginas);
            Console.WriteLine("Porcentaje de lectura: " + ObtenerPorcentajeLectura().ToString("0.00") + "%");
            Console.WriteLine("Cantidad de páginas leídas: " + PaginasLeidas);
            Console.WriteLine("Estado del libro: " + ObtenerEstado());
        }

        public string ObtenerEstado()
        {
            if (leido)
            {
                return "Leído";
            }
            else if (PaginasLeidas > 0)
            {
                return "En proceso";
            }
            else
            {
                return "No leído";
            }
        }
    }
}
