﻿using Desafio_personal;

internal class Program
{
    private static void Main(string[] args)
    {
        Libro libro = new Libro(1, "Harry Potter y el misterio del príncipe", 652);
        libro.MostrarLibro();
        Console.WriteLine("---------------");
        libro.Leer(50);
        libro.MostrarLibro();
        Console.WriteLine("---------------");
        libro.Leer(652);
        libro.MostrarLibro();
    }
}