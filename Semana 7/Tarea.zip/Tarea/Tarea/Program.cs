﻿internal class Program
{
    private static void Main(string[] args)
    {
        
        Console.WriteLine("Diego Urbina 1219823");
        Console.WriteLine("Inciso 1: Promedio de 10 numeros");
        const int Numeros_Maximos = 10;
        double[] numeros = new double[Numeros_Maximos];
        int count = 0;

        Console.WriteLine("Ingrese 10 numeros mayores a 0:");

        while (count < Numeros_Maximos)
        {
            double numero;
            if (double.TryParse(Console.ReadLine(), out numero) && numero > 0)
            {
                numeros[count++] = numero;
            }
            else
            {
                Console.WriteLine("Numero invalido, intente nuevamente.");
            }
        }

        double sum = 0;
        foreach (double numero in numeros)
        {
            sum += numero;
        }

        double promedio = sum / Numeros_Maximos;
        Console.WriteLine("El promedio de los numeros ingresados es: " + promedio);
        
        Console.WriteLine("Inciso 2 generar los primeros 10 numero primos");
        int contador = 0;   
        int incio = 2;
        while (contador < 10 )
            {
            bool esPrimo = true;
            for (int i = 2; i < incio; i++)
            {
                if (incio % i == 0)
                {
                    esPrimo= false;
                    break;
                }

            }
            if (esPrimo)
            {
                Console.WriteLine(incio);
                contador++;
            }
            incio++;
            
        }
    }
}