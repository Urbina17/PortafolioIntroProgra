﻿using System.Diagnostics.CodeAnalysis;

internal class Program
{
    private static void Main(string[] args)
    {
        Console.WriteLine("Diego Urbina 1219823 Mauricio Cabrera 1073323");
        Console.WriteLine("Programa 1");
        Console.Write("Ingrese un número positivo: ");
        int num = int.Parse(Console.ReadLine());
        if (num < 1) {
            Console.WriteLine("El numero ingresado no es válido");
        }else
        {
            for (int i = 1; i <= num; i++) {
                Console.WriteLine(i);
            }
        }
        Console.WriteLine("Programa 2");
        int count = 0;
        int sum = 0;
        string input;
        while (true)
        {
            Console.Write("Ingrese un número o presione n para finalizar: ");
            input = Console.ReadLine();
            if (input.ToLower() == "n") {
                break;
            }
            int numero;
            if (!int.TryParse(input, out numero))
            {
                Console.WriteLine("Numero invalido, ingresar un numero valido");
                continue;
            }
            count++;
            sum += numero;
        }
        if(count > 0)
        {
            double average = (double)sum / count;
            Console.WriteLine("La suma de los números ingresados es: " + sum);
            Console.WriteLine("El promedio de los numero es: " + average);

        } else
        {
            Console.WriteLine("No se ingresaron números");
        }
        Console.WriteLine("Programa 3");
        int total = 0;
        int cantidadProductos = 0;
        Console.WriteLine("Ingrese el valor del producto (para finalizar ingrese -1): ");
        int valordeproducto = int.Parse(Console.ReadLine());
        while (valordeproducto != -1) {
            Console.WriteLine("Ingrese la cantidad de productos: ");
            int cantidad = int.Parse(Console.ReadLine());
            total+= valordeproducto * cantidad;
            cantidadProductos += cantidad;
            Console.WriteLine("Ingrese el valor del producto (para finalizar ingrese -1): ");
            valordeproducto = int.Parse(Console.ReadLine()) ;
        }
        Console.WriteLine("Total a pagar: " + total);
        Console.WriteLine("Cantidad de productos: " + cantidadProductos);
        Console.ReadLine();
    }
}