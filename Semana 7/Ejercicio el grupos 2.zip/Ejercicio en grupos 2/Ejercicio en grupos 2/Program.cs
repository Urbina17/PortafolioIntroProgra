﻿internal class Program
{
    private static void Main(string[] args)
    {
        
        Console.WriteLine("Diego Urbina 1219823 Mauricio Cabrera 1073323");
        Console.WriteLine("Ejercicio 1");
        {
            int sumatoria = 0;
            for (int i = 1; i <= 100; i++)
            {
                Console.Write("Ingresa el numero: ");
                try
                {
                    int numero = int.Parse(Console.ReadLine());
                    sumatoria += numero;
                }
                catch
                {
                    Console.WriteLine("Numero invalido, ingresarlo de nuevo");
                    i--;
                }
            }
            Console.WriteLine("la sumatoria de los 100 numeros es: " + sumatoria);
        }
        
        Console.WriteLine("Programa 2");
        int contador = 0;   
        double suma = 0;
        double estatura;
        do
        {
            Console.Write("Ingrese la estatura en metros, para finalizar ingresar 0: " );
            if (double.TryParse(Console.ReadLine(), out estatura) && estatura != 0)
            {
                suma += estatura;
                contador++;
            }
        }while (estatura !=0);
        if (contador == 0)
        {
            Console.WriteLine("No se ingresaron estaturas");
        }
        else
        {
            double promedio = suma / contador;
            Console.WriteLine("El promedio de las estaturas ingresadas es: " + promedio);
        }
    }
}